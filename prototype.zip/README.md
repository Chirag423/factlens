# FactLens Prototype — Hackathon MVP

A simplified but fully working prototype of the FactLens architecture.
Each section of `prototype.py` maps to a layer in your system diagram.

---

## Quick Start (15 minutes)

### 1. Install Python dependencies

```bash
pip install -r requirements.txt
```

### 2. Download the spaCy NER model

```bash
python -m spacy download en_core_web_sm
```

### 3. (Optional but recommended) Set your Sarvam API key

Get a key at: https://dashboard.sarvam.ai/

```bash
# Mac/Linux:
export SARVAM_API_KEY="your_key_here"

# Windows:
set SARVAM_API_KEY=your_key_here
```

If you skip this, the prototype still works — it just shows raw retrieved articles
instead of a Sarvam-generated answer.

### 4. Run the prototype

```bash
python prototype.py
```

---

## How prototype.py maps to your architecture diagram

| Architecture Layer   | What it uses in the full system          | What `prototype.py` uses instead        |
|----------------------|------------------------------------------|-----------------------------------------|
| Ingestion            | Celery + Feed Fetcher + Article Scraper  | `feedparser` + `trafilatura` (same!)    |
| Processing           | spaCy NER + MiniLM + Entity Resolver     | spaCy NER + MiniLM (same models!)       |
| Storage              | PostgreSQL + Qdrant + Neo4j + Redis      | SQLite (one file, no setup needed)      |
| Retrieval            | asyncio.gather across 3 DBs              | Cosine similarity search on SQLite      |
| Reasoning            | Sarvam API + Prompt Builder              | Sarvam API (same!) or raw results       |

---

## What to do next — Phase 2 upgrades

Once you have the prototype working, upgrade these components one at a time:

### Replace SQLite vectors with real Qdrant

```bash
pip install qdrant-client
```

```python
from qdrant_client import QdrantClient
from qdrant_client.models import Distance, VectorParams, PointStruct

client = QdrantClient(":memory:")  # or host="localhost", port=6333

client.create_collection("articles", vectors_config=VectorParams(
    size=384,  # MiniLM output dimension
    distance=Distance.COSINE
))

# Store:
client.upsert("articles", points=[
    PointStruct(id=chunk_id, vector=embedding.tolist(),
                payload={"title": title, "url": url, "chunk": chunk_text})
])

# Search:
results = client.search("articles", query_vector=query_embedding.tolist(), limit=5)
```

### Add a simple Streamlit web UI

```bash
pip install streamlit
```

```python
# Create app.py:
import streamlit as st
st.title("FactLens")
query = st.text_input("Ask a question about Indian politics:")
if query:
    results = semantic_search(conn, query, embedder)
    answer = query_sarvam(build_rag_prompt(query, results), SARVAM_API_KEY)
    st.write(answer)
    
# Run:
# streamlit run app.py
```

### Add SEBI / Indian Kanoon data

```python
# SEBI orders are public PDFs — use PyPDF2 or pdfplumber:
import pdfplumber
with pdfplumber.open("sebi_order.pdf") as pdf:
    text = "\n".join(page.extract_text() for page in pdf.pages)
# Then pass through the same NER + embedding pipeline
```

---

## File structure

```
factlens/
├── prototype.py       ← Main prototype (start here)
├── requirements.txt   ← pip dependencies
├── README.md          ← This file
└── factlens.db        ← SQLite database (auto-created on first run)
```

---

## Common errors and fixes

| Error | Fix |
|-------|-----|
| `OSError: [E050] Can't find model 'en_core_web_sm'` | Run `python -m spacy download en_core_web_sm` |
| `ModuleNotFoundError: No module named 'feedparser'` | Run `pip install -r requirements.txt` |
| Sarvam API 401 Unauthorized | Check your API key, get one at dashboard.sarvam.ai |
| `factlens.db` getting large | Run `DELETE FROM chunks; DELETE FROM entities; DELETE FROM articles;` to reset |
