#!/usr/bin/env python3
"""
╔══════════════════════════════════════════════════════════════╗
║   FACTLENS PROTOTYPE  —  Hackathon MVP                       ║
║   Political Intelligence & Fact-Verification Agent (India)   ║
╚══════════════════════════════════════════════════════════════╝

HOW THIS MAPS TO YOUR ARCHITECTURE DIAGRAM:
  ┌──────────────┐    This code uses:
  │ Ingestion    │ →  feedparser + trafilatura (RSS → full text)
  │ Processing   │ →  spaCy NER + sentence-transformers (MiniLM)
  │ Storage      │ →  SQLite (simplified PostgreSQL + Qdrant)
  │ Retrieval    │ →  Cosine similarity search (simplified Qdrant)
  │ Reasoning    │ →  Sarvam API (exact same as your full design!)
  └──────────────┘

SETUP STEPS:
  1.  pip install -r requirements.txt
  2.  python -m spacy download en_core_web_sm
  3.  export SARVAM_API_KEY="your_key_here"   (or set it below)
  4.  python prototype.py

PHASE 1 GOAL: Ingest → NER → Store → Search → Answer
"""

import feedparser
import trafilatura
import spacy
import sqlite3
import json
import os
import sys
import numpy as np
import requests
from datetime import datetime
from sentence_transformers import SentenceTransformer

# ╔══════════════════════════════════════════════════════════════╗
# ║  CONFIG — Change these to your values                        ║
# ╚══════════════════════════════════════════════════════════════╝

# Get your Sarvam API key at: https://dashboard.sarvam.ai/
SARVAM_API_KEY = os.getenv("SARVAM_API_KEY", "")

DB_PATH = "factlens.db"

# MiniLM — same model your architecture uses, fast & small (80MB)
EMBEDDING_MODEL = "all-MiniLM-L6-v2"

# Free, public Indian news RSS feeds to start with
RSS_FEEDS = [
    ("The Hindu",           "https://www.thehindu.com/news/national/feeder/default.rss"),
    ("NDTV India",          "https://feeds.feedburner.com/ndtvnews-india-news"),
    ("Economic Times",      "https://economictimes.indiatimes.com/news/politics-and-nation/rssfeeds/1052732854.cms"),
    ("LiveMint",            "https://www.livemint.com/rss/news"),
]

# Entity types to extract (matching your architecture diagram)
NER_TYPES = {"PERSON", "ORG", "GPE", "LAW", "EVENT", "MONEY"}


# ╔══════════════════════════════════════════════════════════════╗
# ║  LAYER 1 — INGESTION                                         ║
# ║  (Replaces: Feed Fetcher + Article Scraper + Celery Queue)   ║
# ╚══════════════════════════════════════════════════════════════╝

def fetch_feed(source_name: str, feed_url: str, max_items: int = 5) -> list[dict]:
    """
    Fetch articles from an RSS feed + scrape full content.

    In the full system, this runs as a Celery worker on a schedule.
    For the prototype, we call it manually.
    """
    print(f"   📡 {source_name}...")

    try:
        feed = feedparser.parse(feed_url)
    except Exception as e:
        print(f"      ⚠️  Could not parse feed: {e}")
        return []

    articles = []
    for entry in feed.entries[:max_items]:
        url = entry.get("link", "")
        title = entry.get("title", "").strip()

        if not url or not title:
            continue

        # Use trafilatura to get the full article text
        # (same library your architecture uses in Article Scraper)
        content = ""
        try:
            raw_html = trafilatura.fetch_url(url)
            if raw_html:
                content = trafilatura.extract(raw_html, include_comments=False) or ""
        except Exception:
            pass  # Skip unfetchable articles silently

        # Only keep articles with meaningful content
        if len(content) > 150:
            articles.append({
                "source": source_name,
                "title": title,
                "url": url,
                "content": content,
                "published": entry.get("published", datetime.now().isoformat()),
            })
            print(f"      ✅ {title[:55]}...")

    return articles


# ╔══════════════════════════════════════════════════════════════╗
# ║  LAYER 2 — PROCESSING                                        ║
# ║  (Replaces: spaCy NER + Entity Resolver + MiniLM Embedder)   ║
# ╚══════════════════════════════════════════════════════════════╝

def extract_entities(text: str, nlp) -> list[dict]:
    """
    Run spaCy NER on article text.

    In the full system, Entity Resolver then de-dupes across articles
    using RapidFuzz fuzzy matching (e.g., "PM Modi" → "Narendra Modi").
    We skip that complexity for now.
    """
    doc = nlp(text[:5000])  # Limit length for speed

    seen = set()
    entities = []
    for ent in doc.ents:
        if ent.label_ in NER_TYPES:
            key = (ent.text.strip().lower(), ent.label_)
            if key not in seen and len(ent.text.strip()) > 2:
                seen.add(key)
                entities.append({"text": ent.text.strip(), "label": ent.label_})

    return entities


def make_chunks(text: str, size: int = 256, overlap: int = 50) -> list[str]:
    """
    Split article text into overlapping word-chunks for embedding.

    Your architecture uses 256-token chunks upserted into Qdrant.
    We do the same chunking, but store embeddings in SQLite instead.
    """
    words = text.split()
    return [
        " ".join(words[i : i + size])
        for i in range(0, len(words), size - overlap)
        if len(words[i : i + size]) > 20
    ]


# ╔══════════════════════════════════════════════════════════════╗
# ║  LAYER 3 — STORAGE                                           ║
# ║  (Replaces: PostgreSQL + Qdrant + Neo4j + Redis)             ║
# ╚══════════════════════════════════════════════════════════════╝

def init_db(conn: sqlite3.Connection):
    """
    Create 3 tables that together mimic your 4-database storage layer:

    articles  → what you'd store in PostgreSQL TimescaleDB
    entities  → simplified version of Neo4j graph (no edges yet)
    chunks    → what you'd store in Qdrant (vectors as JSON for now)
    """
    c = conn.cursor()
    c.executescript("""
        CREATE TABLE IF NOT EXISTS articles (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            source      TEXT,
            title       TEXT,
            url         TEXT UNIQUE,   -- UNIQUE prevents duplicate ingestion (like Redis Seen URLs)
            content     TEXT,
            published   TEXT,
            ingested_at TEXT DEFAULT (datetime('now'))
        );

        CREATE TABLE IF NOT EXISTS entities (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            article_id  INTEGER REFERENCES articles(id),
            entity_text TEXT,
            entity_type TEXT
        );

        CREATE TABLE IF NOT EXISTS chunks (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            article_id  INTEGER REFERENCES articles(id),
            chunk_text  TEXT,
            embedding   TEXT   -- JSON float array — use Qdrant in production!
        );
    """)
    conn.commit()


def save_article(conn, article: dict, entities: list, chunks_with_embeddings: list) -> int | None:
    """
    Save one article + its entities + its embedded chunks.

    Returns the new article ID, or None if it was already in the DB.
    (The UNIQUE constraint on url handles deduplication — like Redis Seen URLs)
    """
    c = conn.cursor()
    try:
        c.execute(
            "INSERT OR IGNORE INTO articles (source,title,url,content,published) VALUES (?,?,?,?,?)",
            (article["source"], article["title"], article["url"],
             article["content"], article["published"]),
        )
        article_id = c.lastrowid
        if not article_id:
            return None  # Already existed

        c.executemany(
            "INSERT INTO entities (article_id,entity_text,entity_type) VALUES (?,?,?)",
            [(article_id, e["text"], e["label"]) for e in entities],
        )

        c.executemany(
            "INSERT INTO chunks (article_id,chunk_text,embedding) VALUES (?,?,?)",
            [(article_id, text, json.dumps(vec.tolist())) for text, vec in chunks_with_embeddings],
        )

        conn.commit()
        return article_id

    except Exception as e:
        conn.rollback()
        print(f"      ❌ Save error: {e}")
        return None


# ╔══════════════════════════════════════════════════════════════╗
# ║  LAYER 4 — RETRIEVAL                                         ║
# ║  (Replaces: Hybrid Retriever + Context Assembler)            ║
# ╚══════════════════════════════════════════════════════════════╝

def cosine_sim(a: np.ndarray, b: np.ndarray) -> float:
    """Cosine similarity between two vectors."""
    denom = np.linalg.norm(a) * np.linalg.norm(b)
    return float(np.dot(a, b) / denom) if denom else 0.0


def semantic_search(conn, query: str, embedder: SentenceTransformer, top_k: int = 5) -> list[dict]:
    """
    Find the most relevant chunks for a query using vector similarity.

    In the full system, this is asyncio.gather across Qdrant + PostgreSQL + Neo4j.
    We do cosine similarity against SQLite-stored vectors (works fine at prototype scale).
    """
    query_vec = embedder.encode(query)

    rows = conn.execute(
        "SELECT c.chunk_text, c.embedding, a.title, a.url, a.source, a.published "
        "FROM chunks c JOIN articles a ON c.article_id = a.id"
    ).fetchall()

    if not rows:
        return []

    results = sorted(
        [
            {
                "score": cosine_sim(query_vec, np.array(json.loads(row[1]))),
                "chunk": row[0],
                "title": row[2],
                "url": row[3],
                "source": row[4],
                "published": row[5],
            }
            for row in rows
        ],
        key=lambda x: x["score"],
        reverse=True,
    )

    return results[:top_k]


def entity_lookup(conn, name: str) -> list[dict]:
    """
    Find all articles mentioning a specific person/org/place.
    Simplified version of Neo4j graph traversal using Cypher.
    """
    rows = conn.execute(
        """SELECT DISTINCT a.title, a.url, a.source, a.content, a.published
           FROM articles a JOIN entities e ON a.id = e.article_id
           WHERE LOWER(e.entity_text) LIKE LOWER(?)
           LIMIT 5""",
        (f"%{name}%",),
    ).fetchall()

    return [
        {"title": r[0], "url": r[1], "source": r[2],
         "content": r[3][:400], "published": r[4]}
        for r in rows
    ]


# ╔══════════════════════════════════════════════════════════════╗
# ║  LAYER 5 — REASONING                                         ║
# ║  (Replaces: Prompt Builder + Sarvam API + Output Parser)     ║
# ╚══════════════════════════════════════════════════════════════╝

def build_rag_prompt(query: str, chunks: list[dict]) -> str:
    """
    Assemble the grounded RAG prompt from retrieved context.
    This is your Prompt Builder component.
    """
    sources = "\n\n---\n\n".join(
        f"[Source {i+1}] {c['source']} — \"{c['title']}\"\n"
        f"URL: {c['url']}\n"
        f"Excerpt: {c['chunk'][:400]}"
        for i, c in enumerate(chunks)
    )

    return f"""You are FactLens, an Indian political intelligence and fact-verification agent.

Answer ONLY from the provided news sources. If the answer is not in the sources, say so clearly.
Always cite which source supports each claim (e.g., "[Source 1]").

NEWS SOURCES:
{sources}

QUESTION: {query}

Give a concise, factual answer with citations."""


def query_sarvam(prompt: str, api_key: str) -> str:
    """
    Send the RAG prompt to Sarvam API and return the grounded answer.

    Sarvam is an Indian AI company — their models understand Indian
    political context, names, and institutions better than generic LLMs.
    Get your API key at: https://dashboard.sarvam.ai/
    """
    try:
        resp = requests.post(
            "https://api.sarvam.ai/v1/chat/completions",
            headers={"Authorization": f"Bearer {api_key}", "Content-Type": "application/json"},
            json={
                "model": "sarvam-m",          # Sarvam's flagship reasoning model
                "messages": [{"role": "user", "content": prompt}],
                "max_tokens": 600,
                "temperature": 0.1,           # Low = more factual, less creative
            },
            timeout=30,
        )
        if resp.status_code == 200:
            return resp.json()["choices"][0]["message"]["content"]
        return f"[Sarvam API Error {resp.status_code}]: {resp.text[:300]}"
    except Exception as e:
        return f"[Connection error]: {e}"


# ╔══════════════════════════════════════════════════════════════╗
# ║  MAIN PIPELINE — Orchestrates all layers                     ║
# ╚══════════════════════════════════════════════════════════════╝

def cmd_ingest(conn, nlp, embedder):
    """Run the full ingestion pipeline."""
    print("\n📥  INGESTION PIPELINE")
    print("─" * 50)
    total = 0

    for name, url in RSS_FEEDS:
        articles = fetch_feed(name, url, max_items=5)

        for article in articles:
            # NER
            ents = extract_entities(article["content"], nlp)

            # Embed chunks
            raw_chunks = make_chunks(article["content"])
            if raw_chunks:
                vecs = embedder.encode(raw_chunks, show_progress_bar=False)
                embedded = list(zip(raw_chunks, vecs))
            else:
                embedded = []

            # Store
            aid = save_article(conn, article, ents, embedded)
            if aid:
                total += 1
                top_ents = ", ".join(e["text"] for e in ents[:4])
                print(f"      → Entities: {top_ents or 'none found'}")

    print(f"\n✅  Done — {total} new articles stored")


def cmd_query(conn, embedder):
    """Run a query against stored articles."""
    query = input("\n❓  Your question: ").strip()
    if not query:
        return

    print("\n🔍  Retrieving relevant context...")
    results = semantic_search(conn, query, embedder, top_k=5)

    if not results:
        print("   No articles found. Run ingestion first (option 1).")
        return

    print(f"   Found {len(results)} chunks | best match score: {results[0]['score']:.3f}")
    print(f"   Top source: \"{results[0]['title'][:60]}\"")

    prompt = build_rag_prompt(query, results)

    if SARVAM_API_KEY:
        print("\n🤖  Querying Sarvam AI...")
        answer = query_sarvam(prompt, SARVAM_API_KEY)
    else:
        print("\n⚠️   No SARVAM_API_KEY set — showing top result instead.")
        print("    Set it with: export SARVAM_API_KEY='your_key'")
        top = results[0]
        answer = (
            f"Top match from \"{top['source']}\":\n"
            f"  Title: {top['title']}\n"
            f"  URL: {top['url']}\n"
            f"  Excerpt: {top['chunk'][:300]}..."
        )

    print(f"\n{'─'*50}")
    print("📰  ANSWER")
    print("─" * 50)
    print(answer)
    print("─" * 50)


def cmd_entity(conn):
    """Look up all articles mentioning a specific entity."""
    name = input("\n👤  Entity name (person/org/place): ").strip()
    if not name:
        return

    results = entity_lookup(conn, name)
    if not results:
        print(f"   No articles found mentioning '{name}'")
        return

    print(f"\n   Found {len(results)} articles mentioning '{name}':\n")
    for r in results:
        print(f"   [{r['source']}] {r['title']}")
        print(f"   {r['url']}")
        print(f"   {r['content'][:200]}...")
        print()


def cmd_stats(conn):
    """Show database stats."""
    arts  = conn.execute("SELECT COUNT(*) FROM articles").fetchone()[0]
    ents  = conn.execute("SELECT COUNT(*) FROM entities").fetchone()[0]
    chunks = conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
    
    print(f"\n📊  Database: {DB_PATH}")
    print(f"   Articles   : {arts}")
    print(f"   Entities   : {ents}")
    print(f"   Chunks     : {chunks}")

    if arts:
        top = conn.execute(
            "SELECT source, COUNT(*) as n FROM articles GROUP BY source ORDER BY n DESC"
        ).fetchall()
        print("\n   Articles by source:")
        for src, n in top:
            print(f"     {src:<25} {n}")


def main():
    print()
    print("╔══════════════════════════════════════════════════════════╗")
    print("║   🔍  FACTLENS — Political Intelligence Agent (India)    ║")
    print("╚══════════════════════════════════════════════════════════╝")

    # ─── Load models (takes ~10s the first time, cached after) ───────────
    print("\n⚙️   Loading models (first run downloads ~80MB)...")

    conn = sqlite3.connect(DB_PATH)
    init_db(conn)

    try:
        nlp = spacy.load("en_core_web_sm")
    except OSError:
        print("\n❌  spaCy model not found. Run:")
        print("       python -m spacy download en_core_web_sm")
        sys.exit(1)

    print("   Loading MiniLM embedding model...")
    embedder = SentenceTransformer(EMBEDDING_MODEL)

    if SARVAM_API_KEY:
        print(f"   Sarvam API key: {'*' * (len(SARVAM_API_KEY)-4)}{SARVAM_API_KEY[-4:]}")
    else:
        print("   ⚠️  No Sarvam API key — queries will show raw results")

    print("\n✅  Ready!\n")

    # ─── CLI loop ────────────────────────────────────────────────────────
    menu = """
┌─────────────────────────────────────┐
│  1. Ingest articles (fetch + store) │
│  2. Ask a question                  │
│  3. Look up an entity               │
│  4. Show stats                      │
│  5. Exit                            │
└─────────────────────────────────────┘"""

    while True:
        print(menu)
        choice = input("  Choice [1-5]: ").strip()

        if choice == "1":
            cmd_ingest(conn, nlp, embedder)
        elif choice == "2":
            cmd_query(conn, embedder)
        elif choice == "3":
            cmd_entity(conn)
        elif choice == "4":
            cmd_stats(conn)
        elif choice == "5":
            print("\n   Goodbye! 👋\n")
            break
        else:
            print("   Please enter 1–5")

    conn.close()


if __name__ == "__main__":
    main()
